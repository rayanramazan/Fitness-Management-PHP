CREATE DATABASE IF NOT EXISTS `gym`;

USE `gym`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `gender` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `admin` VALUES (1,"rayan ramazan","rayan@gmail.com",111,9647100944,"چڕە","نێر"),
(2,"رەیان","rayan@gmail.com","b79465edbb2036fa2cb1f488c01747ab1b808939ac2973d275968c38b00254d2",9647100944,"چڕە","نێر"),
(3,"ahmad","rr@gmail.com","5b07c66d439fa40f128a4dd4a71c56cc7ae6d6a01b9dab900c4d2934b8631d78",07507523900,"duhok","نێر"),
(4,"هێزا ئەقلێ ڤەشارتى","rayanramazan09@gmail.com","6a015a0f86de26f49624ca463ced5dd911c7dfe148e1c40cee995d1c5bfa1228",9647100944,"چڕە","نێر"),
(6,"ahmad","rayan1@gmail.com","5b07c66d439fa40f128a4dd4a71c56cc7ae6d6a01b9dab900c4d2934b8631d78",9647100944,"چڕە","نێر"),
(7,"رێنحبەر","renjbar@gmail.com","b79465edbb2036fa2cb1f488c01747ab1b808939ac2973d275968c38b00254d2",07517100944,"چرە","نێر"),
(8,"عەزیز","aziz@gmail.com","b79465edbb2036fa2cb1f488c01747ab1b808939ac2973d275968c38b00254d2",9647100944,"چڕە","نێر");


DROP TABLE IF EXISTS `protin`;

CREATE TABLE `protin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `admin_id` varchar(255) NOT NULL,
  `protin_name` varchar(255) NOT NULL,
  `price_protin` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `protin` VALUES (1,"رەیان رەمەزان",7,"phd",90000,"2022-03-02"),
(2,"رەیان رەمەزان",7,"phd",90000,"2022-03-02");


DROP TABLE IF EXISTS `useful`;

CREATE TABLE `useful` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `useful` VALUES (1,"رەیان رەمەزان",115000),
(2,"ئەحمەد یونس",115000),
(3,"ردوان کەمال",115000),
(4,"سارا ئەحمەد",115000),
(5,"محمد میرۆ",115000),
(6,"رێنجبەر محمد رسول",115000),
(7,"رەیان رەمەزان",115000),
(8,"رەیان رەمەزان",115000),
(9,"ردوان کەمال",115000),
(10,"ئەرسەلان عنتر",115000),
(11,"کاروان رەشید",25000);


DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `admin_id` varchar(255) NOT NULL,
  `categories_gym` varchar(200) NOT NULL,
  `address` varchar(255) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `price` int(11) NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `month` int(11) NOT NULL,
  `qarz` tinyint(1) NOT NULL,
  `price_qarz` int(11) NOT NULL,
  `month_qarz` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `user` VALUES (1,"رەیان رەمەزان",7,"ئشتراک دگەل ئاڤێ","چرە","نێر",30000,"2022-03-02","2022-04-02",1,0,0,1),
(2,"ئەحمەد یونس",7,"ئشتراکا عادی","چرە","نێر",25000,"2022-03-02","2022-04-02",1,0,0,0),
(3,"ردوان کەمال",8,"ئشتراک دگەل ساونا","ئاکرێ","نێر",25000,"2022-03-05","2022-04-05",2,0,0,0),
(4,"سارا ئەحمەد",8,"ئشتراکا عادی","کەلەکچى","مێ",30000,"2022-03-03","2022-04-03",3,1,55000,2),
(9,"ردوان کەمال",7,"ئشتراکا عادی","ئاکرێ","نێر",30000,"2022-03-03","2022-04-03",2,0,0,2),
(10,"ئەرسەلان عنتر",7,"ئشتراکا عادی","شێخان","نێر",25000,"2022-03-03","2022-04-03",1,0,0,0),
(11,"کاروان رەشید",8,"ئشتراکا عادی","ئاکرێ","نێر",25000,"2022-03-05","2022-04-05",1,0,0,0);


SET foreign_key_checks = 1;
